
import { ActionTypes } from "../constants/action-types";
const initialState={
    products:[
        {
        id:1,
        tittle:"Dipesh",
        catogory:"programer"
    },
],
}
export const productReducer = (state=initialState,{type,payload})=>{
    switch(type){
        case ActionTypes.SET.PRODUCTS:
            return state;
        default:
            return state;
    }
};