import React, { useEffect, useState } from "react";
import axios from "axios";
import './App.css';

export default function App() {
  const [data, setData] = useState([]);
  const [records, setRecords] = useState([]);
  //Api For Distric List
  useEffect(() => {
    axios
      .get(`http://api.nightlights.io/districts`)
      .then((res) => {
        setData(
          res.data.regions.sort(function (a, b) {
            return compareStrings(a.district_name, b.district_name);
          })
        );
        setRecords(
          res.data.regions.sort(function (a, b) {
            return compareStrings(a.district_name, b.district_name);
          })
        );
      })
      .catch((err) => console.log(err));
  }, []);
  //Handled OnChange Event with Filter
  const handleFilter = (event) => {
    if (event && event.target.value && event.target.value !== "") {
      setRecords(
        data &&
          data
            .filter((filterItem) =>
              filterItem.district_name
                .toLowerCase()
                .includes(event.target.value)
            )
            .sort(function (a, b) {
              return compareStrings(a.district_name, b.district_name);
            })
      );
    } else {
      setRecords(
        data.sort(function (a, b) {
          return compareStrings(a.district_name, b.district_name);
        })
      );
    }
  };
  //Shorting the List
  function compareStrings(a, b) {
    a = a.toLowerCase();
    b = b.toLowerCase();

    return a < b ? -1 : a > b ? 1 : 0;
  }
  return (
    <div className="App">
      <div className="search-header">
        <div className="search-text">Search:</div>
        <input
          id="search-box"
          onChange={(e) => handleFilter(e)}
          placeholder="Search..."
        />
      </div>
      <div id="item-list">
        <ul className="listStyle">
          {records &&
            records.length &&
            records.length > 0 &&
            records.map((item, index) => (
              <li key={index + 1}>{item.district_name}</li>
            ))}
        </ul>
      </div>
    </div>
  );
}
